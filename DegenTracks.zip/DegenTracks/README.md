# DegenTracks

Minimal FastAPI app (DegenTracks) with JWT auth and a tiny dashboard.
See RENDER_DEPLOY.md for deployment instructions.
